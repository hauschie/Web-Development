'use strict';

const PORT = 3000;

// The variable stocks has the same value as the variable stocks in the file 'stocks.js'
const stocks = require('./stocks.js').stocks;

const express = require("express");
const app = express();


app.use(express.urlencoded({
    extended: true
}));

app.use(express.static('public'));
// Note: Don't add or change anything above this line.

function findStockBySymbol(symbolToLookUp)  {
    /*
    Takes the symbol user entered as a parameter and returns
    the object which corresponds to that stock.
    */
    for (let item of stocks) {
        for (let key in item) {
            if (item[key] == symbolToLookUp) {
                return item
            }
        }
    }

}


function findStockByPrice(lowestOrHighest) {
    /*
    Takes as a parameter whether the user wants the lowest or
    highest numer and returns the stock with the lowest or highest value.
    */
   let currentMaxOrMin = 0
   let valueToReturn = "None"
    if (lowestOrHighest == "lowest") {
        for (let item of stocks) {
            for (let key in item) {
                if (key == "price") {
                    if (item[key] < currentMaxOrMin || currentMaxOrMin == 0) {
                        currentMaxOrMin = item[key];
                        valueToReturn = item;
                    }
                }
            }
        }
    }   
    if (lowestOrHighest == "highest") {
        for (let item of stocks) {
            for (let key in item) {
                if (key == "price") {
                    if (item[key] > currentMaxOrMin || currentMaxOrMin == 0) {
                        currentMaxOrMin = item[key];
                        valueToReturn = item;
                    }
                }
            }
        }
    }
    return valueToReturn
}

app.get("/review1", (req, res) => {
    const symbolOfStock = req.query.symbol;
    const quantityToBuy = req.query.quantity;
    const stockObject = findStockBySymbol(symbolOfStock)
    const stockName = stockObject["company"]
    const stockPrice = stockObject["price"]
    const totalValue = quantityToBuy * stockPrice
    res.send(`You placed an order to buy ${quantityToBuy} 
    stocks of ${stockName}. The price of one stock is $${stockPrice} 
    and the total price for this order is $${totalValue}.`);
})

app.get("/review2", (req, res) => {
    res.send(findStockByPrice(req.query.price))
})


// Note: Don't add or change anything below this line.
app.listen(PORT, () => {
    console.log(`Server listening on port ${PORT}...`);
});