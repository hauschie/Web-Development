import React from 'react';
import { Link } from 'react-router-dom';

function HomePage(props){
    return (
        <div>
            <h2>
            Welcome to Beaver Mart!
            </h2>
            <body>
                <p>
                Order What You Need
                </p>
                <Link className="app-link" to="/OrderPage"> Shop online</Link>
                <p>
                From Our Stores Across the Country
                </p>
                <Link className="app-link" to="/StoresPage"> See a list of Beaver Mart Stores</Link>
            </body>
        </div>
    )
}

export default HomePage