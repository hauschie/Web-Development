import React from 'react';
import { Link } from 'react-router-dom';
import GroceryTable from '../components/GroceryTable';

function OrderPage(props) {

    return (
        <div>
            <h2>
            Order Page
            </h2>
            <body>
                <p>
                Select the quantity of the items you want to buy
                </p>
                <br />
                <GroceryTable items={props.items} />
                <br />
                <Link className="app-link" to="/"> Go to Home Page</Link>
            </body>
        </div>
    )
}

export default OrderPage;
