import React from 'react';
import { Link } from 'react-router-dom';
import StoreTable from '../components/StoreTable';
import ZipSearch from '../components/ZipSearch';


function StoresPage(props){

    return (
        <div>
            <h2>
            Store List
            </h2>
            <body>
                <p>
                Select the quantity of items you want to buy
                </p>
                <center>
                <StoreTable stores={props.stores} />
                </center>
                <br/>
                <ZipSearch />
                <br/>
                <Link className="app-link" to="/"> Go to Home Page</Link>
                <br/>
            </body>
        </div>
    )
}


export default StoresPage;