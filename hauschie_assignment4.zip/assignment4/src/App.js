import './App.css';
import stores from './data/stores';
import items from './data/items';
import React from 'react';
import {BrowserRouter as Router, Route} from 'react-router-dom';
import HomePage from './pages/HomePage';
import OrderPage from './pages/OrderPage';
import StoresPage from './pages/StoresPage';

function App() {  

  return (
    <div className="App">
      <header className="App-header">
        <Router>
          <header className="App-header">
            <Route path="/" exact>
              <HomePage />
            </Route>
            <Route path="/OrderPage">
              <OrderPage items={items}/>
            </Route>
            <Route path="/StoresPage">
              <StoresPage stores={stores}/>
            </Route>
          </header>
        </Router>
      </header>
    </div>
  );
}

export default App;
