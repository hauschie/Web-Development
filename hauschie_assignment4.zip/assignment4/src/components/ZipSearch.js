import React, { useState } from 'react';

function ZipSearch() {
  const [name, setName] = useState('');
  return (
    <div className="App">
        <form>
            <fieldset>
            <legend>Zip Code</legend>
            <label>Please enter a five-digit zip code:
                <input type="number" value={name}
                onChange={e => setName(e.target.value)} />
            </label>
            </fieldset>
            <button onClick={e => {
            setName(e.target.value);
            alert(`Your zip code is ${name}`);
            e.preventDefault();
            }}>Submit</button>
        </form>
    </div>
  );
}

export default ZipSearch;