import React, { useState } from 'react';
import ZipSearch from './ZipSearch';

function StoreRow(props) {
    return (
    <tr>
        <td>{props.store.city}</td>
        <td>{props.store.state}</td>
        <td>{props.store.zipCode}</td>
    </tr>
  );
}

export default StoreRow;