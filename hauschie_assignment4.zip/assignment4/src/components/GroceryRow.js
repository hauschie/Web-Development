import React, { useState } from 'react';
import SelectQuantity from './SelectQuantity';

function GroceryRow(props) {
    return (
    <tr>
        <td>{props.item.name}</td>
        <td>{props.item.price}</td>
        <td><SelectQuantity/></td>
    </tr>
  );
}

export default GroceryRow;