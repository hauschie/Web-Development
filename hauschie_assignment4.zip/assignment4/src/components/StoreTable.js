import React from 'react';
import StoreRow from '../components/StoreRow';

function StoreTable(props) {
    return (
        <div>
        <table>
            <caption>Store Table</caption>
            <thead>
            <tr>
                <th>City</th>
                <th>State</th>
                <th>Zip</th>
            </tr>
            </thead>
            <tbody>
                {
                props.stores.map(function(store){
                    return <StoreRow store={store} />
                })
                }
            </tbody>
          </table>
        </div>
  )
}

export default StoreTable;