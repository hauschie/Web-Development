import React, { useState } from 'react';
import { HiPlus, HiMinus } from "react-icons/hi";
	
function SelectQuantity() {
    const [count, setCount] = useState(0);
    const increment = () => setCount(count + 1);
    const dontChange = () => setCount(count);
    const decrement = () => setCount(count - 1);
    return (
      <div>
        <HiMinus onClick={count > 0 ? decrement : dontChange } />
        <span>{count}</span>
	    <HiPlus onClick={count < 10 ? increment : dontChange } />
      </div>
     );
}

export default SelectQuantity;