import React from 'react';
import GroceryRow from '../components/GroceryRow';

function GroceryTable(props) {
    return (
        <div>
        <table>
            <caption>Stock Order Table</caption>
            <thead>
            <tr>
                <th>Name</th>
                <th>Price</th>
                <th>Quantity</th>
            </tr>
            </thead>
            <tbody>
                {
                props.items.map(function(item){
                    return <GroceryRow item={item} />
                })
                }
            </tbody>
          </table>
        </div>
  )
}

export default GroceryTable;