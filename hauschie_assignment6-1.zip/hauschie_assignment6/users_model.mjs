import mongoose from 'mongoose';
import 'dotenv/config';

mongoose.connect(
    process.env.MONGODB_CONNECT_STRING,
    { useNewUrlParser: true }
);

const db = mongoose.connection;

const userSchema = mongoose.Schema({
    name: { type: String, required: true},
    age: { type: Number, required: true},
    email: { type: String, required: true},
    phoneNumber: { type: String, required: false}
});

const User = mongoose.model("User", userSchema);

/**
* @param {String} name
* @param {Number} age
* @param {String} email
* @param {String} phoneNumber
* @returns
*/

const createUser = async (name, age, email, phoneNumber) => {
    const user = new User({name: name, age: age, email: email, phoneNumber: phoneNumber});
    return user.save();
}

const findUsers = async (filter) => {
    const query = User.find(filter);
    return query.exec();
}

const updateUser = async (filter, update) => {
    const result = await User.updateOne(filter, update);
    return result.modifiedCount;
}

const deleteById = async (filter, update) => {
    const result = await User.deleteMany(filter, update);
    return result.deletedCount;
}

db.once("open", () => {
    console.log("Successfully connected to MongoDB using Mongoose!");
});

export { createUser, findUsers, updateUser, deleteById };