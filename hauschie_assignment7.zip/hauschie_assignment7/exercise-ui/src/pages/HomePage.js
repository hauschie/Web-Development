import React from 'react';
import { Link } from 'react-router-dom';
import { MdHome, MdAddCircle } from 'react-icons/md';
import ExerciseList from '../components/ExerciseList';
import { useState, useEffect } from 'react';
import { useHistory } from 'react-router-dom';



function HomePage({ setExerciseToEdit }) {

    const [exercises, setExercises] = useState([]);
    const history = useHistory();

    const onDelete = async _id => {
        const response = await fetch(`/exercises/${_id}`, { method: 'DELETE' }); // fetch API: communicate with the REST API server
        if (response.status === 204) {
            setExercises(exercises.filter(m => m._id !== _id));
        } else {
            console.error(`Couldn't delete the exercise: ID: = ${_id}, Status Code = ${response.status}`);
        }
    };


    
    const onEdit = exercise => {
        setExerciseToEdit(exercise);
        history.push("/edit-exercise");
    }

    const loadExercises = async () => { 
        const response = await fetch('/exercises'); 
        const data = await response.json(); 
        setExercises(data); 
    }

    useEffect(() => {
        loadExercises();
    }, []);

    return (
        <body>
            <header className="nav-bar">
                <div className="nav-links">
                    <p><Link className="App-link" to="/"><MdHome /></Link></p>
                </div>
                <div className="nav-links">
                    <p><Link className="App-link" to="/create-exercise"><MdAddCircle /></Link></p>
                </div>
            </header>

            <main>
                <h2>Exercise List</h2>
                <ExerciseList exercises={exercises} onDelete={onDelete} onEdit={onEdit}></ExerciseList>

                {<Link className="App-link" to="/create-exercise">
                    <button type="button">
                        Add an exercise
                    </button>
                </Link>}
            </main>
        </body>

    );
}

export default HomePage;