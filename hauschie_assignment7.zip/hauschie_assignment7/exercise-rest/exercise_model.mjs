import mongoose from 'mongoose';

mongoose.connect(
    `mongodb+srv://Eric:test1@cluster1.8fhom.mongodb.net/?retryWrites=true&w=majority`,
    { useNewUrlParser: true }
);

const db = mongoose.connection;

db.once("open", () => {
    console.log("Connected to MongoDB.");
});


const entrySchema = mongoose.Schema(
    {name: { type: String, required: true },
        reps: { type: Number, required: true },
        weight: { type: Number, required: true },
        unit: { type: String, required: true },
        date: { type: String, required: true },
    }
);

const Entry = mongoose.model("Entry", entrySchema);


const createExercise = async (name, reps, weight, unit, date) => {
    
    const entry = new Entry( {name: name, reps: reps, weight: weight, unit: unit, date: date} );
    return entry.save();
}


const findExercises = async () => {
    return Entry.find().exec();
}

const replaceExercise = async (entryId, updates) => {
    return Entry.findOneAndUpdate( {_id: entryId}, updates );
}

const deleteExercise = async (entryId) => {
     return Entry.deleteOne( {_id: entryId} );
}

export { createExercise, findExercises, replaceExercise, deleteExercise };