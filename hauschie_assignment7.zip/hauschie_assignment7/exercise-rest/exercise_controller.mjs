import express from 'express';
import { createExercise, findExercises, replaceExercise, deleteExercise } from './exercise-model.mjs';


const PORT = 3000;

app.use(express.json());
const app = express();


app.post('/exercises', ( req, res ) => {
    const { name, reps, weight, unit, date } = req.body;
    console.log("Create request received.");
    createExercise( name, reps, weight, unit, date )
    .then( newEntry => { res.status(201).json(newEntry); } )
    .catch( error => { 
        console.error(error);
        res.status(400).json({ Error: "Invalid request"}); 
    });
});

app.get('/exercises', (req, res)=>{
    console.log("Retrieve request received.");
    findExercises()
    .then( entryArray => { res.status(200).json(entryArray) } )
    .catch( error => { 
        console.error(error);
        res.status(400).json({Error: 'Failed request'}); 
    });
});

app.put('/exercises/:_id', (req, res)=>{
    console.log("Update request received.")
    const updates = req.body;
    console.log(updates);
    replaceExercise(req.param._id, updates)
    .then(() => { res.status(200).json({_id: req.params._id, ...req.body}); })
    .catch(error => { 
        console.error(error);
        res.status(404).json({ Error: "Not found"});
    });
});

app.delete('/exercises/:_id', (req, res)=>{
    console.log("Delete request received.");
    deleteExercise(req.param._id)
    .then(()=>{res.status(204).end()})
    .catch(error => {
        console.error(error);
        res.status(404).json({ Error: "Not found"});
    });
});


// START SERVER
app.listen(PORT, () => {console.log(`Server listening on port ${PORT}`)});