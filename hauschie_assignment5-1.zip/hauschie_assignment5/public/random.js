'use strict'

function addData(data) {
    const p = document.createElement('p');
    p.textContent = data.results[0].name.first + " " + data.results[0].name.first + ", Phone: " + data.results[0].phone + ", Email: " + data.results[0].email
    p.style.backgroundColor = 'aqua';    
    const xhrdata = document.getElementById('data');
    xhrdata.appendChild(p);
}

function getData(url) {
    return fetch(url)
        .then(response => response.json())
        .then(data => addData(data))
        .catch(error => console.error(error));
}

function callServer(event) {
    event.preventDefault();
    console.log('Sending request to server');
    getData('/random-user');
}

function dirLink(event) {
    event.preventDefault();
    console.log('Getting data for direct link')
    getData("https://randomuser.me/api/")
}


document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('explink');
    form.addEventListener('click', callServer);
});

document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('dirlink');
    form.addEventListener('click', dirLink);
});