
 async function urlResponse(urlApi){
    const response = await fetch(urlApi);
    let data1 = await response.json();
    let data2 = data1.results[0].name.first
    console.log(data1.results[0].name.first)
    return data2
    }

    fetch('http://example.com/movies.json')
  .then(response => response.json())
  .then(data => console.log(data1.results[0].name.first));

function doLongOp(index) {
    return items[index];
}
    
    /**
     * Handler for GET requests for /longop
     */
app.get('/longop', (req, res) => {
    console.log(req.query);
    const retVal = doLongOp(req.query.urlResponse(url1));
    console.log(retVal);
    res.send(retVal);
});

fetch(apiUrl, {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json'
    },
    body: JSON.stringify(
        
    )
}).then(res => {
        return res.json()
    })
        .then(data => console.log(data))
        .catch(error => console.log('ERROR'))




        
fetch("https://randomuser.me/api/")
.then(response => response.json())
.then(data => console.log(data.results[0].name.first));