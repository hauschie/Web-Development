import express from 'express';
import fetch from 'node-fetch';
import 'dotenv/config';
import asyncHandler from 'express-async-handler';

const PORT = process.env.PORT
const app = express();

app.use(express.static('public'));

// Note: Don't add or change anything above this line.
'use strict'

const apiUrl = "https://randomuser.me/api/"
const count = 1500;
let timesClicked = 0;

function countingClicks(req, res, next) {
    timesClicked += 1
    if (timesClicked % 10 == 0) {
        console.log(`Total retrieve requests: ${timesClicked}`)
    }
    next();
}

app.get('/random-user', countingClicks, async (req, res) => {
    try {
        const response = await fetch(apiUrl);
        const data = await response.json();
        res.send(data);
    } catch (error) {
        console.log(error);
        res.status(500).send(error.message)
    }
});

app.listen(PORT, () => {
    console.log(`Server listening on port ${PORT}...`);
});